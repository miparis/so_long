/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   window.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: miparis <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/09/03 11:28:00 by miparis           #+#    #+#             */
/*   Updated: 2024/09/03 11:28:02 by miparis          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "so_long_bonus.h"

int	hooks_loops(t_data *mlx_ptr)
{
	mlx_key_hook(mlx_ptr->w_ptr, on_key_press, mlx_ptr);
	mlx_hook(mlx_ptr->w_ptr, KeyRelease, KeyReleaseMask, \
			&on_key_press, mlx_ptr);
	mlx_hook(mlx_ptr->w_ptr, DestroyNotify, StructureNotifyMask, \
			&end_game, mlx_ptr);
	return (0);
}

int	on_key_press(int keysym, t_data *data)
{
	char *str;

	if (keysym == 65307)
	{
		end_game(data);
		exit(5);
	}
	mlx_clear_window(data->mlx_ptr, data->w_ptr);
	render(data);
	move_player(keysym, data);str = ft_itoa(data->game->counter);
	str = ft_itoa(data->game->counter);
	mlx_string_put(data->mlx_ptr, data->w_ptr, \
	TILE_SIZE * 0.4, (data->map->height + 0.5) * TILE_SIZE, 0xffffff, str);
	free(str);
	return (0);
}
