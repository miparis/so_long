/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   utils.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: miparis <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/08/27 10:10:10 by miparis           #+#    #+#             */
/*   Updated: 2024/08/27 10:10:12 by miparis          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "so_long.h"

//This function initializes the connection to the graphical system and returns a void pointer that can be used later to refer to this instance.
/*void *mlx_init(void)
{
	t_data	*mlx_ptr;

	mlx_ptr = (t_data*)malloc(sizeof(t_data));
	if (!mlx_ptr)
	{
		ft_printf("Memory allocation for MLX failed\n");
		return (NULL);
	}
	return (mlx_ptr);
}*/

int on_destroy(t_data *mlx_ptr)
{
	mlx_destroy_window(mlx_ptr->mlx_ptr, mlx_ptr->window_ptr);
	mlx_destroy_display(mlx_ptr->mlx_ptr);
	free(mlx_ptr->mlx_ptr);
	exit(0);
	return (0);
}

int on_key_press(int keysym, t_data *data)
{
	(void)data;
	if (keysym == XK_Escape)
	{
		ft_printf("Closing :)...\n");
		mlx_destroy_window(data->mlx_ptr, data->window_ptr);
		mlx_destroy_display(data->mlx_ptr);
		free(data->mlx_ptr);
		exit(5);
	}
	ft_printf("Key pressed: %d\n", keysym);
	return (0);
}


int charge_images(t_data data)
{
	int i;
	int height;
	int width;

	i = -1;
	//check if there is any other way to put this values as macros
	height = 1024;
	width = 1024;
	data.textures[0]= mlx_xpm_file_to_image(data.mlx_ptr, "assets/Plaster.xpm", &width, &height);
	data.textures[1]= mlx_xpm_file_to_image(data.mlx_ptr, "assets/Stone.xpm",  &width, &height);
	data.textures[2]= mlx_xpm_file_to_image(data.mlx_ptr, "assets/frozen.xpm",  &width, &height);
	data.textures[3]= mlx_xpm_file_to_image(data.mlx_ptr, "assets/empanada.xpm",  &width, &height);
	while (i++ < 4)
	{
		if (!data.textures[i])
		{
			ft_printf("Failed to load image %d\n", i);
			free(data.mlx_ptr);
			return (1);
			//exit (3);
		}
	}
	//here tile size indicates the position in x & z where we want to put the image
	mlx_put_image_to_window(data.mlx_ptr, data.window_ptr, data.textures[2], TILE_SIZE, TILE_SIZE);
	return(0);
}
