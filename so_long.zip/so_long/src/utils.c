/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   utils.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: miparis <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/08/27 10:10:10 by miparis           #+#    #+#             */
/*   Updated: 2024/08/27 10:10:12 by miparis          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "so_long.h"

void	print_map_screen(t_data *data)
{
	int		x;
	int		y;

	y = 0;
	while (data->map->map[y])
	{
		//printf("=> {%s}\n", data->map->map[y]);
		x = 0;
		while (data->map->map[y][x])
		{
			//printf("Zi: %d, Xi: %d => [%c]\n", y, x, data->map->map[y][x]);
			if (data->map->map[y][x] == '0')
				mlx_put_image_to_window(data->mlx_ptr, data->window_ptr, data->textures[0], x*TILE_SIZE, y*TILE_SIZE);
			if (data->map->map[y][x] == '1')
				mlx_put_image_to_window(data->mlx_ptr, data->window_ptr, data->textures[1], x*TILE_SIZE, y*TILE_SIZE);
			if (data->map->map[y][x] == 'P')
				mlx_put_image_to_window(data->mlx_ptr, data->window_ptr, data->textures[2], x*TILE_SIZE, y*TILE_SIZE);
			if (data->map->map[y][x] == 'C')
				mlx_put_image_to_window(data->mlx_ptr, data->window_ptr, data->textures[3], x*TILE_SIZE, y*TILE_SIZE);
			if (data->map->map[y][x] == 'E')
				mlx_put_image_to_window(data->mlx_ptr, data->window_ptr, data->textures[4], x*TILE_SIZE, y*TILE_SIZE);
			x++;
		}
		y++;

	}
}

int on_destroy(t_data *mlx_ptr)
{
	(void)mlx_ptr;
	/* TODO: decomment */
	// mlx_destroy_window(mlx_ptr->mlx_ptr, mlx_ptr->window_ptr);
	// mlx_destroy_display(mlx_ptr->mlx_ptr);
	// free(mlx_ptr->mlx_ptr);
	exit(0);
	return (0);
}

int on_key_press(int keysym, t_data *data)
{
	move_player(keysym, data);
	if (keysym == XK_Escape)
	{
		ft_printf("Closing :)...\n");
		/* TODO: decomment */
		// mlx_destroy_window(data->mlx_ptr, data->window_ptr);
		// mlx_destroy_display(data->mlx_ptr);
		// free(data->mlx_ptr);
		exit(5);
	}
	//print_map_screen(data);

	ft_printf("Key pressed: %d\n", keysym);
	return (0);
}

int charge_images(t_data *data)
{
	int 	i;
	int 	height;
	int 	width;

	i = -1;
	data->textures[0]= mlx_xpm_file_to_image(data->mlx_ptr, "assets/floor.xpm", &width, &height);
	data->textures[1]= mlx_xpm_file_to_image(data->mlx_ptr, "assets/wall.xpm",  &width, &height);
	data->textures[2]= mlx_xpm_file_to_image(data->mlx_ptr, "assets/character.xpm",  &width, &height);
	data->textures[3]= mlx_xpm_file_to_image(data->mlx_ptr, "assets/empanada.xpm",  &width, &height);
	data->textures[4]= mlx_xpm_file_to_image(data->mlx_ptr, "assets/plane.xpm",  &width, &height);
	while (++i < 5)
	{
		if (!data->textures[i])
		{
			ft_printf("Failed to load image %d\n", i);
			free(data->mlx_ptr);
			return (1);
			//exit (3);
		}
	}
	//here tile size indicates the position in x & z where we want to put the image
	// mlx_put_image_to_window(data.mlx_ptr, data.window_ptr, data.textures[2], TILE_SIZE, TILE_SIZE);
	return(0);
}

void	move_player(int keycode, t_data *data)
{

	/* TODO: Fix */
	//arreglar los valores de keycode para que tomen las arrows y  a,d,s,w
	init_game(data);
	if (keycode == XK_Right)
		move(data, (data->game->x_player + 1) , data->game->y_player);
	if (keycode == XK_Left)
		move(data, (data->game->x_player - 1) , data->game->y_player);
	if (keycode == XK_Pointer_Down)
		move(data, (data->game->x_player) , data->game->y_player + 1);	
	if (keycode == XK_Pointer_Up)
		move(data, (data->game->x_player) , data->game->y_player - 1);
	render(data);
}

void init_game(t_data *data)
{
	data->game->counter = 0;
	data->game->x_player = data->map->start_x;
	data->game->y_player = data->map->start_y;
	data->game->collectable = 0;
}
