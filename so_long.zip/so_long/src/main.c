/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: miparis <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/08/22 11:51:56 by miparis           #+#    #+#             */
/*   Updated: 2024/08/22 11:51:58 by miparis          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include "so_long.h"

int main(int argc, char **argv)
{
	t_map		map;

	if (argc != 2 || check_file(argv[1]))
	{
		ft_printf("Error: Cant use map :(\n");
		return (1);
	}
	if (!map_control(&map, argv[1]) == 0)
	{
		free_split(map.map);
		return (-1);
	}
	free_split(map.map);
	return (0);
}




/*
int	main(void)
{
	t_data 	data;

	data.mlx_ptr = mlx_init();
	if(!data.mlx_ptr)
		return (1);
	data.window_ptr = mlx_new_window(data.mlx_ptr, 1920, 1080, "joego todo goapo :)");
	if (!data.window_ptr)
	{
		ft_printf("Window creation failed\n");
		return (free(data.mlx_ptr), 1);
	}
	//mlx_loop_hook(data.mlx_ptr, &charge_images, &data);
	mlx_key_hook(data.window_ptr, on_key_press, &data);
	mlx_hook(data.window_ptr, KeyRelease, KeyReleaseMask, &on_key_press, &data);
	mlx_hook(data.window_ptr, DestroyNotify, StructureNotifyMask, &on_destroy, &data);
	charge_images(data);
	
	mlx_loop(data.mlx_ptr);
	mlx_destroy_window(data.mlx_ptr, data.window_ptr);
	mlx_destroy_display(data.mlx_ptr);
	free(data.mlx_ptr);
	return (0);
}*/
