/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   so_long.h                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: miparis <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/08/22 11:52:06 by miparis           #+#    #+#             */
/*   Updated: 2024/08/22 11:52:08 by miparis          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef SO_LONG_H
# define SO_LONG_H

# include "../includes/printf/ft_printf.h"
# include "../includes/libft/libft.h"
# include "../mlx_linux/mlx.h"
#include <stdio.h>
#include <stdlib.h>
#include <X11/X.h>
#include <X11/keysym.h>
#include <fcntl.h>

#define TILE_SIZE 64
#define WIDHT 64
#define HEIGHT 64

typedef struct s_data
{
	void		*mlx_ptr; // MLX pointer
	void		*window_ptr; // MLX window pointer
	void		*textures[5]; // MLX image pointers (on the stack)
	//t_map		*map; // Map pointer (contains map details - preferably kept on the stack)
}	t_data;

typedef struct s_map
{
	size_t		width;
	size_t		height;
	char		**map;
	int			player;
	int			exit;
	int			collectable;
}	t_map;

/*					TITLE										*/
int		on_key_press(int keycode, t_data *mlx_ptr);
int		on_destroy(t_data *mlx_ptr);
int		charge_images(t_data data);
void	create_window(t_data data);

/*					FILE & MAP									*/
int		check_file(char *file);
int		char_validation(char *file);
int 	calculate_dimension(char *file, t_map *map);
void	initialize_struct(t_map *map);
int 	map_memory(t_map *map);
int		map_population(char *file, t_map *map);
int 	map_control(t_map *map, char *file);
int		objs_control(t_map *map);
int		border_control(t_map *map);
void 	print_map(t_map *map);


#endif
