/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   movements.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: miparis <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/09/04 11:37:57 by miparis           #+#    #+#             */
/*   Updated: 2024/09/04 11:37:58 by miparis          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "so_long.h"

/* TODO: Decomment */
//esta actualizando mal los valores del jugador, hay 
void	move(t_data *data, int x, int y)
{
	if (x < 0 || y < 0)
		return ;
	if (data->map->map[y][x] == '1')
		return ;
	if (data->map->map[y][x] == 'C')
	{
		data->game->collectable++;
		data->map->map[data->game->y_player][data->game->x_player] = '0';
		data->map->map[y][x] = '0';
	}
	if (data->map->map[y][x] == '0')
	{
		data->game->counter++;
		data->map->map[data->game->y_player][data->game->x_player] = '0';
		data->map->map[y][x] = 'P';
	}
	if (data->map->map[y][x] == 'E')
	{
		player_out(data);
		return ;
	}
	data->game->x_player = x;
	data->game->x_player = y;
}

void player_out(t_data *data)
{
	if (data->game->collectable == data->map->collectable)
	{
		data->game->counter++;
		end_game(data);
	}
}

void	end_game(t_data *data)
{
	free_split(data->map->map);
	free(data->map);
	free(data->game);
	free(data);
	exit(0);
}