/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   window.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: miparis <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/09/03 11:28:00 by miparis           #+#    #+#             */
/*   Updated: 2024/09/03 11:28:02 by miparis          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "so_long.h"

int init_window(t_data *mlx_ptr, t_map *map)
{
	size_t	width;
	size_t	height;

	width = (map->width - 1) * TILE_SIZE;
	height = map->height * TILE_SIZE;
	mlx_ptr->window_ptr = mlx_new_window(mlx_ptr->mlx_ptr, width, height, "joego todo goapo :)");
	if (!mlx_ptr->window_ptr)
	{
		ft_printf("Window creation failed\n");
		return (free(mlx_ptr->mlx_ptr), 1);
	}
	return (0);
}

int	render(t_data *data)
{
	static int i = 0;
	print_map_screen(data);
	
	i++;
	//printf("=> %d\n", i);

	return (0);
}

int	hooks_loops(t_data *mlx_ptr)
{
	mlx_key_hook(mlx_ptr->window_ptr, on_key_press, mlx_ptr);
	mlx_hook(mlx_ptr->window_ptr, KeyRelease, KeyReleaseMask, &on_key_press, mlx_ptr);
	mlx_hook(mlx_ptr->window_ptr, DestroyNotify, StructureNotifyMask, &on_destroy, mlx_ptr);
	//mlx_loop_hook(mlx_ptr->mlx_ptr, render, mlx_ptr);
	return (0);
}
