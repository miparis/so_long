/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   map.c                                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: miparis <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/08/28 10:48:20 by miparis           #+#    #+#             */
/*   Updated: 2024/08/28 10:48:23 by miparis          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "so_long.h"

int check_file(char *file)
{
    const char	*ext;
    size_t		file_len;
    size_t		ext_len;
	char		*file_ext;
	int 		fd;
    
	ext = ".ber";
	file_len = ft_strlen(file);
	ext_len = ft_strlen(ext);
	fd = open(file, O_RDONLY);
	if (fd < 0)
		return (1);
    if (file_len < ext_len) 
        return 1; 
    file_ext = ft_substr(file, file_len - ext_len, ext_len);
    if (ft_strcmp(file_ext, ext) != 0)
	{
		free(file_ext);
		return 1;
	}
	free(file_ext);
	return (0);
}

int	char_validation(char *file)
{
	int		fd;
	char	*line;
	int		j;

	fd = open(file, O_RDONLY);
	if (fd < 0)
		return (ft_printf("Error: Can't open file\n"), 1);
	while ((line = get_next_line(fd)) != NULL)
	{
		j = 0;
		while (line[j])
		{
			if (line[j] != '1' && line[j] != '0' && line[j] != 'P' 
				&& line[j] != 'E' && line[j] != 'C' && line[j] != '\n' )
			{
				ft_printf("Error: Invalid character in map :(\n");
				free(line);
				return (close(fd), 1);
			}
			j++;
		}
		free(line);
	}
	return (close(fd), 0);
}

int 	calculate_dimension(char *file, t_map *map)
{
	char	*line;
	int 	fd;
	size_t	line_len;

	fd = open(file, O_RDONLY);	
	if (fd < 0)
		return (ft_printf("Error: Can't open file\n"), 1);
	initialize_struct(map);
	while ((line = get_next_line(fd)) != NULL)
	{
		map->height++;
		line_len = ft_strlen(line);
		if (map->width == 0)
			map->width = line_len;
		else
		{
			if (line[line_len - 1] != '\n')
				line_len++;
			if (map->width != line_len)
				return (ft_printf("Error: Map with incorrect size\n"), close(fd), free(line), 1);
			map->width = line_len;
		}
		free(line);
	}
	return (free(line), close(fd), 0);
}


void initialize_struct(t_map *map)
{
	map->width = 0;
	map->height = 0;
	map->player = 0;
	map->exit = 0;
	map->collectable = 0;
	map->map = NULL;
}


int 	map_memory(t_map *map)
{
	size_t 	i;

	i = 0;
	map->map = malloc(sizeof(char *) * (map->height + 1));
	if (!map->map)
		return (ft_printf("Error: Memory allocation failed\n"), 1);
	while (i < map->height)
	{
		map->map[i] = malloc(sizeof(char) * (map->width + 1));
		if (!map->map[i])
		{
			while (map->map[i])
				free(map->map[i]);
			free(map->map);
			ft_printf("Error: Memory allocation failed\n");
			return (6);
		}
		i++;
	}
	map->map[i] = NULL;
	return (0);
}

int 	map_population(char *file, t_map *map)
{
	int		fd;
	char	*line;
	size_t	i;

	i = 0;
	fd = open(file, O_RDONLY);
	if (fd < 0)
		return (ft_printf("Error: Can't open file\n"), 1);
	while ((line = get_next_line(fd)) != NULL)
	{
		ft_strlcpy(map->map[i], line, map->width);
		free(line);
		i++;
	}
	free(line);
	return (close(fd), 0);
}

int	objs_control(t_map *map)
{
	size_t	i;
	size_t	j;
	char 	current;

	i = 0;
	while (i < map->height)
	{		
		j = 0;
		while (j < map->width)
		{
            current = map->map[i][j];
            if (current == 'P')
			{
                map->player++;
                if (map->player > 1)
                    return (ft_printf("Error: Multiple players found\n"), 1);
            }
			else if (current == 'E') 
			{
                map->exit++;
                if (map->exit > 1)
                    return (ft_printf("Error: Multiple exits found\n"), 1);
            } 
			else if (current == 'C') 
                map->collectable++;
            j++;
        }
        i++;
    }
    if (map->player != 1 || map->exit != 1 || map->collectable == 0)
        return (ft_printf("Error: Map must contain at least 1 of each object\n"), 1);
    return 0;
}

int	border_control(t_map *map)
{
	size_t	i;
	size_t	j;

	i = 0;
	while (i < (map->width - 1))
	{
		if (map->map[0][i] != '1' || map->map[map->height - 1][i] != '1')
			return (ft_printf("Error: Map must have borders :,( \n"), 1);
		i++;
	}
	j = 0;
	while (j < map->height)
	{
        if (map->map[j][0] != '1' || map->map[j][strlen(map->map[j]) - 1] != '1')
			return (ft_printf("Error: Map must have borders :( \n"), 1);
        j++;
    }
    return 0;
}

char **copy_map(char **original, size_t height, size_t width)
{
	size_t 	i;
	size_t 	j;
	char 	**copy;

	copy = ft_calloc((height + 1), sizeof(char *));
	if (!copy)
		return (NULL);
	i = 0;
	while (i < height)
	{
		copy[i] = malloc(sizeof(char) * (width + 1));
        if (!copy[i])
		{
            j = -1;
            while (j++ < i)
                free(copy[j]);
            return (free(copy), NULL);
        }
        ft_strlcpy(copy[i], original[i], width);
        copy[i][width] = '\0';
        i++;
    }
    return (copy);
}

int	find_player(t_map *map)
{
	size_t		i;
	size_t		j;

	i = 0;
	while (i < map->height)
	{
		j = 0;
		while (j < map->width)
		{
			if (map->map[i][j] == 'P')
			{
				map->start_x = j;
				map->start_y = i;
				return (0);
			}
			j++;
		}
		i++;
	}
	return (1);
}

void	rec_check(char **map, int x, int y)
{
	if (map[y][x] == '1')
		return ;
	map[y][x] = '1';
	rec_check(map, x, y -1); //arriba
	rec_check(map, x + 1, y); //derecha
	rec_check(map, x, y + 1); //abajo
	rec_check(map, x - 1, y); //izquierda
}

int 	check_valid_map(t_map *map)
{
	char	**map_copy;
	size_t		i;
	size_t		j;

	find_player(map);
	map_copy = copy_map(map->map, map->height, map->width);
	rec_check(map_copy, map->start_x, map->start_y);
	i = 0;
	while (i < map->height)
	{
		j = 0;
		while (j < map->width)
		{
			if (map_copy[i][j] == 'E' || map_copy[i][j] == 'C')
			{
				ft_printf("Error: Unreachable object \n");
				return (1);
			}
			j++;
		}
		i++;
	}
	free_split(map_copy);
	return (0);
}

int 	map_control(t_map *map, char *file)
{
	if (char_validation(file))
		return (1);
	if (calculate_dimension(file, map))
		return (1);
	if (map_memory(map))
		return (1);
	if (map_population(file, map))
		return (1);
	if (objs_control(map))
		return (1);
	if (border_control(map))
		return (1);
	if (check_valid_map(map))
		return (1);
	//print_map(map);
	return (0);
}
/*
void print_map(t_map *map)
{
    size_t i, j;

    for (i = 0; i < map->height; i++)
    {
        for (j = 0; j < map->width; j++)
            ft_putchar(map->map[i][j]); // Assuming ft_putchar is a function to print a single character
        ft_putchar('\n'); // New line after each row
    }
}*/