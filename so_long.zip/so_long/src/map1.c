/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   map.c                                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: miparis <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/08/28 10:48:20 by miparis           #+#    #+#             */
/*   Updated: 2024/08/28 10:48:23 by miparis          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "so_long.h"

int	check_file(char *file)
{
	const char	*ext;
	size_t		file_len;
	size_t		ext_len;
	char		*file_ext;
	int			fd;

	ext = ".ber";
	file_len = ft_strlen(file);
	ext_len = ft_strlen(ext);
	fd = open(file, O_RDONLY);
	if (fd < 0)
		return (1);
	if (file_len < ext_len)
		return (1);
	file_ext = ft_substr(file, file_len - ext_len, ext_len);
	if (ft_strcmp(file_ext, ext) != 0)
	{
		free(file_ext);
		return (1);
	}
	free(file_ext);
	return (0);
}

int	char_validation(char *file)
{
	int		fd;
	char	*line;
	int		j;

	fd = open(file, O_RDONLY);
	if (fd < 0)
		return (ft_printf("Error: Can't open file\n"), 1);
	line = get_next_line(fd);
	while (line != NULL)
	{
		j = 0;
		while (line[j])
		{
			if (line[j] != '1' && line[j] != '0' && line[j] != 'P' \
					&& line[j] != 'E' && line[j] != 'C' && line[j] != '\n')
			{
				ft_printf("Error: Invalid character in map :(\n");
				return (free(line), close(fd), 1);
			}
			j++;
		}
		free(line);
		line = get_next_line(fd);
	}
	return (close(fd), 0);
}

int	map_control(t_map *map, char *file, int argc, char **argv)
{
	initialize_struct(map);
	if (argc != 2 || check_file(argv[1]))
	{
		ft_printf("Error: Can´t use map :(\n");
		return (1);
	}
	if (char_validation(file))
		return (1);
	if (calculate_dimension(file, map))
		return (ft_printf("Error: Map with wrong size\n"), 1);
	if (map_memory(map))
		return (1);
	if (map_population(file, map))
		return (1);
	if (objs_control(map))
		return (1);
	if (border_control(map))
		return (1);
	if (check_valid_map(map))
		return (1);
	//print_map(map);
	return (0);
}
void print_map(t_map *map)
{
    size_t i, j;

    for (i = 0; i < map->height; i++)
    {
        for (j = 0; j < map->width; j++)
            ft_putchar(map->map[i][j]); // Assuming ft_putchar is a function to print a single character
        ft_putchar('\n'); // New line after each row
    }
}